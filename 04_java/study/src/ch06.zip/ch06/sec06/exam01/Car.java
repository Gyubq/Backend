package ch06.sec06.exam01;

public class Car {
    // 필드선언
    String model;
    String color ;
    int spped ;


    // 변수 초기화를 해주지않은상태이기때문에 0이들어갈것이다
    // boolean = F , int = 0 , string = null
    // model = null , start = f , int = 0

}
