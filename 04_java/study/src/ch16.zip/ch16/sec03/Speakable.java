package ch16.sec03;

@FunctionalInterface
public interface Speakable {
    void speak(String content);
}
